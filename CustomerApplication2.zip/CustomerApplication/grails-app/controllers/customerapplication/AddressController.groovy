package customerapplication

class AddressController {
    def create() {
        def districtList = District.list();
        [districtList:districtList];
    }
    def operation() {
        def addressList = Address.list();
        model:[addressList:addressList]
    }
    def save() {
        def addressIns = new Address();
        def id1 = params.distId;
        def id = Integer.parseInt(id1)
        def districtIns = District.get(params?.long('distId'));
        addressIns.doorNo = params?.doorNo;
        addressIns.streetName = params.streetName;
        addressIns.area = params.area;
        addressIns.pincode = params.pincode;
        addressIns.district = districtIns;
        if(addressIns?.validate()){
            addressIns.save(flush:true);
            redirect action:"operation"
        } else {
            flash.message="Please check all the fields"
            redirect action:"create"
        }
    }
    def list() {
        def addressList = Address.list(params)
        [addressList:addressList,addressCount:Address.count()]
    }
    def delete() {
        def doorNo = params.doorNo;
        def addressIns = Address.get(doorNo)
        addressIns.delete(flush:true)
        redirect action:"operation"
    }
     
}
