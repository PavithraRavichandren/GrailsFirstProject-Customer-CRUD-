package customerapplication
import java.text.SimpleDateFormat
class CustomerController {
    def create() {
        def addressList = Address.list()
        [addressList:addressList]
    }
    def operation() {
        def customerList = Customer.list()
        [customerList:customerList]
    }
    def save() {
        def customerIns = new Customer();
        customerIns.name = params.name;
        customerIns.bloodGroup = params.bloodGroup
        customerIns.dob = params.dateOfBirth
        customerIns.email = params.email
        customerIns.password = params.password
        def addressIns = Address.get(params.long("doorNo"));
        customerIns.address = addressIns;
        if(customerIns.validate()) {
            customerIns.save(flush:true);
            redirect action: "operation"
        } else {
            flash.message="Please check all the fields"
            redirect action:"create"
        }
    }
    def list() {
        params.max = Math.min(params?.max ? params?.int('max') : 5, 4)
        [customerList:Customer.list(params),customerCount:Customer.count()]
    }
    def delete() {
        def customerName = params.customerName
        def customerIns = Customer.get(customerName)
        customerIns.delete(flush:true)
        redirect action:"operation"
    }
    def update() {
        def id = Integer.parseInt(params.oldCustomerName)
        def oldCustomerName = Customer.get(id)
        def newCustomerName = params.newCustomerName
        oldCustomerName.name=newCustomerName
        redirect action:"operation"
    }
    def search() {
    
    }
    def find() {
        def find = Customer.createCriteria()
        def findBy = params.optionValue
        def value = params.value
        def dateOfBirth = params.dateOfBirth
        println "dateOfBirth ${dateOfBirth}"
        if(findBy.equals("dob")) {
            def customerList = find.list {
            like(findBy,dateOfBirth)
            System.out.println(dateOfBirth)
            }
            def customerCount = Customer.count()
            render(view:"list",model:[customerList:customerList,customerCount:customerCount])
        } else {
             value= value+"%"
             def customerList = find.list {
            like(findBy,value)
            }
            // customerList = customerList.list(params)
            def customerCount = Customer.count()
            render(view:"list",model:[customerList:customerList,customerCount:customerCount])
        }
    }
    
}

