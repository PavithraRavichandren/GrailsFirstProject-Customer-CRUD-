package customerapplication

import org.apache.poi.hssf.usermodel.HSSFWorkbook
import org.apache.poi.hssf.util.HSSFColor
import org.apache.poi.ss.usermodel.Workbook
import org.apache.poi.ss.usermodel.Sheet
import com.google.common.collect.ArrayTable.Row
import org.h2.result.Row
import javax.swing.DefaultRowSorter.Row
import org.hsqldb.Row
import org.springframework.web.multipart.MultipartHttpServletRequest
import  org.springframework.web.multipart.MultipartFile
import com.sun.rowset.internal.Row
import javax.swing.text.ParagraphView.Row
import com.google.common.collect.StandardTable.Row
import org.apache.poi.ss.usermodel.Row
import com.google.common.collect.Table.Cell
import org.apache.poi.ss.usermodel.Cell
import org.apache.poi.hssf.usermodel.HSSFSheet
import org.apache.poi.hssf.usermodel.HSSFCell
import org.apache.poi.hssf.usermodel.HSSFRow
import org.apache.commons.io.monitor.FileEntry
import org.apache.poi.hssf.usermodel.HSSFRichTextString
import org.apache.poi.ss.usermodel.RichTextString
import com.lowagie.text.Font
import com.lowagie.text.pdf.CFFFont.Font
import java.awt.Font
import org.apache.poi.ss.usermodel.Font
import org.apache.poi.xssf.usermodel.XSSFFont
import org.xhtmlrenderer.css.parser.property.PrimitivePropertyBuilders.Color
import sun.font.FontFamily
import org.apache.poi.hssf.usermodel.HSSFPalette
import org.apache.poi.ss.usermodel.Color
import java.awt.Color
import org.apache.poi.ss.usermodel.CellStyle
import org.apache.poi.xssf.usermodel.XSSFColor
import org.apache.poi.hssf.usermodel.HSSFFont
import org.apache.poi.xssf.usermodel.XSSFCellStyle
import org.apache.poi.hssf.usermodel.HSSFCellStyle
class CountryController {
    def operation() {
        def countryList = Country.list()
        [countryList:countryList]
    }
    def create() {
    }
    def save() {
       def countryIns = new Country(params)
       if(countryIns.validate()) {
            countryIns.save(flush: true, failOnError: true)
            redirect action:"operation"
        } else {
            flash.error = "Please check all the fields"
            render(view:"create")
        }
    }
    def list() {
        params.max = Math.min(params?.max ? params?.int('max') : 5, 4)
        def countryList = Country.list(params);
        [countryList:countryList,countryCount:Country.count()]
    }
    def doDelete() {
        def country = params.country;
        def countryIns = Country.get(country);
        countryIns.delete(flush:true);
        redirect action:"operation"
    }
    def doUpdate() {
        def id = Integer.parseInt(params.oldCountry);
        def oldCountry = Country.get(id);
        def newCountry = params.newCountry;
        oldCountry.country = newCountry;
        redirect action:"operation"  
    }
    def delete() {
        [countryList:Country.list()]
    }
    def update() {
        [countryList:Country.list()]
    }
    def export() {
        def countryList = Country.list()
        HSSFWorkbook workBook = new HSSFWorkbook()
        HSSFSheet sheet = workBook.createSheet("Excel Sheet")
        HSSFRow rowHead = sheet.createRow((short) 0)
        rowHead.createCell((short) 0).setCellValue("Country Name")
        rowHead.createCell((short) 1).setCellValue("Continent Name")
        short index = 1
        for(Country countryIns: countryList) {
            rowHead = sheet.createRow(index)
            rowHead.createCell((short) 0).setCellValue(countryIns.country)
            rowHead.createCell((short) 1).setCellValue(countryIns.continent)
            index++
        }
        FileOutputStream fileOutput = new FileOutputStream("c:\\sample.xls")
        workBook.write(fileOutput)
        fileOutput.close()
        println "File exported successfully"
        redirect action:"list"
    }
    def importFile() {
        MultipartFile multiPartFileIns = ((MultipartHttpServletRequest) request).getFile('choose_file')
        InputStream inputStream = new ByteArrayInputStream(multiPartFileIns?.getBytes())
        Workbook workbook = new HSSFWorkbook(inputStream)
        HSSFSheet sheet = workbook.getSheetAt(0)
        sheet.each {
            row1 -> new Country(country:row1.getCell((short) 0).getStringCellValue(),
                                continent:row1.getCell((short) 1).getStringCellValue()).save(flush:true)
        }
        redirect action:"list"
    }
   def excelToHTML() {
        InputStream inputStream = new FileInputStream("c:\\convert.xls")
        Map<RichTextString,Short[]> map = new LinkedHashMap<RichTextString,Short[]>()
        Workbook workbook = new HSSFWorkbook(inputStream)
        HSSFSheet sheet = workbook.getSheetAt(0)
        RichTextString richString = null;
       Short[] b = null;
        for(Row row:sheet) {
            for(Cell cell:row) {
                richString = new HSSFRichTextString(cell.getStringCellValue())
                CellStyle cellStyle = cell.getCellStyle()
                HSSFColor color = cellStyle.getFillForegroundColorColor()
                Short[] a = color.getTriplet()
                Font font = workbook.getFontAt(cellStyle.getFontIndex())
                
                println "font ${font}"
//                HSSFColor fcolor = font.getHSSFColor();
//                println "font ${font} ${font.getItalic()}"
//               // println "\n${font.getColor()}    dvf ${font.getFamily()}"
                if(richString.toString()!="")
                map.put(richString,a)
            }
            map.put(new HSSFRichTextString("."),b)
        }
//        for(Map.Entry<RichTextString,Short[]>map1:map.entrySet()) {
//                println "key ${map1.getKey()} value ${map1.getValue()}"
//        }
//        String str = "<b>Pavithra</b>"
        [dataMap:map,str:str]
        
    }   
    
    def fontStyles() {
        String a="",styles="",value="",dummy="",newLine="",table="<table border='1px'>"
        int flag=1
        Short[] rgb = new Short[3]
        Short[] bgc = new Short[3]
        HSSFFont font1=null
        HSSFFont font =null 
        InputStream inputStream = new FileInputStream("sample.xls")
        Workbook workbook = new HSSFWorkbook(inputStream)
        HSSFSheet sheet = workbook.getSheetAt(0)
        HSSFPalette paletteIns=null;
        for(Row row:sheet) {
            value=""
            table = table+"<tr>"
            for(Cell cell:row) {
                flag=1
                value=""
                HSSFColor color=null
                HSSFColor color1=null
                HSSFColor background=null
                HSSFRichTextString richString = cell.getRichStringCellValue()
                String string = richString.toString()
                println "richString ${string}"
                HSSFCellStyle cs = cell.getCellStyle()
                if(richString.length()==0) {
                    flag=0
                }
                background = cs.getFillForegroundColorColor()
                Short[] bg = background.getTriplet()
                bgc[0] = bg[0]
                bgc[1] = bg[1]
                bgc[2] = bg[2]
                if( (bgc[0]==0) && (bgc[1]==0) && (bgc[2]==0) ) {
                    bgc[0] = 255
                    bgc[1] = 255
                    bgc[2] = 255
                }
                println "bgc[0] ${bgc[0]} bgc[1] ${bgc[1]} bgc[2] ${bgc[2]}"
                table=table+"<td style=\"background-color:rgb("+bgc[0]+","+bgc[1]+","+bgc[2]+");\">"
                for(int i=0;i<richString.length();i++) {
                    newLine=""
                    if(i<richString.length()-1) {
                        font1 = workbook.getFontAt(richString.getFontAtIndex(i+1))
                    } else {
                        font1 = workbook.getFontAt(richString.getFontAtIndex(i))
                    }
                     println "richString.getFontAtIndex(i)ffffff ${richString.getFontAtIndex(i)}"
                    if(richString.getFontAtIndex(i)==0) {
                        font = workbook.getFontAt(cs.getFontIndex())
                        font1 = workbook.getFontAt(cs.getFontIndex())
                    } else {
                         font1 = workbook.getFontAt(richString.getFontAtIndex(i+1))
                         font = workbook.getFontAt(richString.getFontAtIndex(i))       
                    }
                    if(!(string.charAt(i).toString().equals(" "))){
                        paletteIns = ((HSSFWorkbook)workbook).getCustomPalette()
                        color = paletteIns.getColor(font.getColor())
                        color1 = paletteIns.getColor(font1.getColor())
                        Short[] r = color?.getTriplet()
                        if(r!=null) {
                            rgb[0] = r[0]
                            rgb[1] = r[1]
                            rgb[2] = r[2]
                        }
                        
                       
                        
                        if( (font.getItalic()) && (font.getUnderline()) && 
                            (font.getBoldweight()==700)) {
                            dummy="<i><u><b>"+string.charAt(i).toString()+"</b></i></u>"
                        } else if( (font.getItalic()) && (font.getBoldweight()==700) ) {
                            dummy="<i><b>"+string.charAt(i).toString()+"</b></i>"
                        } else if( (font.getBoldweight()==700) && (font.getUnderline() ) ){
                            dummy="<b><u>"+string.charAt(i).toString()+"</u></b>"
                        } else if(font.getItalic() && (font.getUnderline() )) {
                            dummy="<u><i>"+string.charAt(i).toString()+"</i></u>"
                        } else if(font.getItalic()) {
                            dummy="<i>"+string.charAt(i).toString()+"</i>"
                        } else if(font.getUnderline()) {
                            dummy="<u>"+string.charAt(i).toString()+"</u>"
                        } else if(font.getBoldweight()==700) {
                            dummy="<b>"+string.charAt(i).toString()+"</b>"
                        }else {
                            dummy=string.charAt(i).toString()
                        } 
                        
                        if( (!color)&&(!color1)) {
                           rgb[0]=0
                           rgb[1]=0
                           rgb[2]=0
                       }
                        
                        if(string.charAt(i).toString().equals("\n")) {
                            newLine="<br>"
                        }
                        
                        
                        if( (color&&color1)&&(font.getFontName().equals(font1.getFontName())) 
                            &&(font.getFontHeightInPoints().equals(font1.getFontHeightInPoints()))
                            &&(Arrays.equals(color?.getTriplet(),
                                    color1?.getTriplet()))
                            && (!(string.charAt(i).toString().equals("\n"))) ) {
                            value=value+dummy
                        }else {
                            styles=table+"<span style=\"font-family:"+font.getFontName()+";font-size:"+font.getFontHeightInPoints()+"px;color:rgb("+rgb[0]+","+rgb[1]+","+rgb[2]+");\">"+value+""+dummy+""+"</span>"+newLine
                            table=""
                            a=a+styles
                            value=""
                            flag=1 
                        }
                    }else {
                        value=value+" "
                    }
                }
                if(flag==1) {
                    styles=table+"<span style=\"font-family:"+font.getFontName()+";font-size:"+font.getFontHeightInPoints()+"px;color:rgb("+rgb[0]+","+rgb[1]+","+rgb[2]+");\">"+value+""+"</span>"+newLine
                    table=""
                    a=a+styles
                    flag=0;
                }  
                a=a+"</td>"
            }
            a=a+"</tr>"
            table=""
        }
        a=a+"</table>"
        println a
        render view:"excelToHTML", model:[str:a]
    }
    String applyStyles(String word) {
        
        
    }
}

