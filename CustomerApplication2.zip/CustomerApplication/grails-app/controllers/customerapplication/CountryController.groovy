package customerapplication

class CountryController {
    def operation() {
        def countryList = Country.list();
        [countryList:countryList]
    }
    def create() {
    }
    def save() {
       def countryIns = new Country(params)
       if(countryIns.validate()) {
            countryIns.save(flush: true, failOnError: true)
            redirect action:"operation"
        } else {
            flash.error="Please check all the fields"
            render(view:"create")
        }
    }
    def list() {
        def countryList = Country.list(params);
        [countryList:countryList,countryCount:Country.count()]
    }
    def doDelete() {
        def country = params.country;
        def countryIns = Country.get(country);
        countryIns.delete(flush:true);
        redirect action:"operation"
    }
    def doUpdate() {
        def id = Integer.parseInt(params.oldCountry);
        def oldCountry = Country.get(id);
        def newCountry = params.newCountry;
        oldCountry.country = newCountry;
        redirect action:"operation"  
    }
    def delete() {
        [countryList:Country.list()]
    }
    def update() {
        [countryList:Country.list()]
    }
}