package customerapplication

class DistrictController {

    def create() {
        def stateList = State.list()
        model:[stateList:stateList]
    }
    def operation() {
        def districtList = District.list()
        model:[districtList:districtList]
    }
    def save() {
        def districtName = params.districtName
        def stateId1 = params.stateName
        Integer stateId = Integer.parseInt(stateId1)
        def stateIns = State.get(stateId)
        def districtIns = new District()
        districtIns.name = districtName
        districtIns.state = stateIns
        if(districtIns.validate()) {
            districtIns.save(flush:true)
            redirect action:"operation"
        } else {
            flash.message="Please check all the fields"
            redirect action:"create"
        }
    }
    
    def list() {
        def districtList = District.list(params)
        [districtList:districtList,districtCount:District.count()]
    }
    
    
    def delete() {
        def districtName = params.district
        def districtIns = District.get(districtName)
        districtIns.delete(flush:true)
        redirect action: "operation"
    }
    def update() {
        def id = Integer.parseInt(params.oldDistrict)
        def oldDistrict = District.get(id)
        def newDistrict = params.newDistrict
        oldDistrict.name = newDistrict
        redirect action:"operation"
       
    }
}
